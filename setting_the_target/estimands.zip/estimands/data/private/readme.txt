README for estimands/data/private

This folder contains private data files that cannot be shared publicly.

To access the GSS files for the Buchmann and DiPrete example, visit https://gss.norc.org/ The files used in this code are named buchmann_GSS.dat and buchmann_GSS.dct, though the names will be different when you download.

To access the Current Population Survey for the Pal and Waldfogel example, visit cps.ipums.org. The file used in the code is named cps_00040.dta, though the name will be different when you download.

To access the Fragile Families and Child Wellbeing Study data, visit fragilefamilies.princeton.edu. The file used in the code is named ff_res_merge4.dta. This file should have the same name when you download.