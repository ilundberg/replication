
# This file runs all the code to produce the results in our paper:
# Setting the Target: Precise Estimands and the Gap Between Theory and Empirics
# Ian Lundberg, Rebecca Johnson, and Brandon Stewart
# Email: ilundberg@princeton.edu

setwd("/Users/iandl/downloads/estimands")

set.seed(08544)

# The following code files can be run independently and in any order.

source("code/PalWaldfogel_replication.R")
rm(list = ls())

source("code/BuchmannDiPrete_replication.R")
rm(list = ls())

source("code/WildemanEtAl_replication.R")
rm(list = ls())

source("code/risk_ratio_difference.R")
rm(list = ls())
